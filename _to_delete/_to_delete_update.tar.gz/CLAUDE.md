# Golden Gift — Personalized Gifts Marketplace

Multi-vendor personalized-gift e-commerce platform for Iraq / Kurdistan. Flutter monorepo with two independent sub-projects sharing one Firebase backend. Structure and conventions mirror the **BB** project (`~/AndroidStudioProjects/BB`).

**Single source of truth for scope and behaviour:** `docs/GOLDENGIFT_SRS.md` (same content in `docs/GoldenGift_SRS.docx`). Implement phase by phase in the order defined there. Do not add features that are not in the SRS without updating the SRS first.

## Monorepo Structure

```
mobile/          # Flutter customer app (v1.0.0) — iOS, Android, Web
adminDashboard/  # Flutter web admin dashboard (v1.0.0) — Web only
docs/            # SRS + design references
```

Both connect to Firebase project **`goldengift`** (same Firestore, Auth, Storage).

## First-time setup (platform folders are not committed yet)

```bash
cd mobile && flutter create . --org com.goldengift --project-name golden_gift --platforms=android,ios,web
cd mobile && flutterfire configure --project=goldengift   # generates lib/firebase_options.dart
cd mobile && flutter pub get && flutter gen-l10n && flutter analyze

cd adminDashboard && flutter create . --org com.goldengift --project-name golden_gift_admin --platforms=web
cd adminDashboard && flutterfire configure --project=goldengift
cd adminDashboard && flutter pub get && flutter analyze
```

## Quick Commands

```bash
cd mobile && flutter run                     # mobile device
cd mobile && flutter gen-l10n                # after editing ARB files in assets/lang/
cd adminDashboard && flutter run -d chrome   # web only
```

## Tech Stack (mandatory)

- Flutter 3.x / Dart >=3.0.0, **Riverpod** (`flutter_riverpod`) — NOT Bloc, NOT Provider
- **GoRouter** flat route list; bottom nav is `MainShell` + `IndexedStack` (no ShellRoute), no `refreshListenable`
- Firebase: Auth (phone OTP, email, Google, Apple), Firestore, Storage, Messaging, Analytics, App Check
- Cloud Functions (`mobile/functions/`, Node 20 / TypeScript) for: AI Gift Search (Gemini), referral credit, order notifications, gift-card codes. Client must degrade gracefully when a function is unavailable.
- Localization: `en`, `ar` (RTL), `ckb` (Kurdish Sorani, RTL) — ARB files in `mobile/assets/lang/`. Admin dashboard is English only.
- Currency: **IQD** (0 decimals). Always `CurrencyFormatter.format()`.

## Shared Firestore Collections

Top-level: `users`, `stores`, `products`, `categories`, `orders`, `carts`, `wishlists`, `banners`, `promo_codes`, `gift_card_templates`, `gift_cards`, `wallets`, `referrals`, `special_requests`, `secret_santa_groups`, `notifications`, `reviews`, `ai_searches`, `app_settings`

Admin-only: `admins`, `admin_audit_log`

Collection paths are defined in:
- `mobile/lib/core/constants/firestore_paths.dart`
- `adminDashboard/lib/core/constants/firestore_paths.dart`

If you add a collection, update BOTH files and the SRS data model.

## Enums — single definition, must NOT diverge

`OrderStatus`, `PaymentMethod`, `PaymentStatus`, `OptionType`, `ProductAvailability`, `ReferralStatus`, `SpecialRequestStatus`, `WalletTxnType` are defined identically in `mobile/lib/core/constants/app_constants.dart` and `adminDashboard/lib/core/constants/admin_constants.dart`. Firestore stores the string values listed in the SRS §6.

## Design System — Gold & White / Gold & Black

Brand: **Primary Gold `#C9A227`**, Accent Gold `#E3C04A`, Deep Gold `#9C7A14`, Soft Gold tint `#FBF4DC`. **Light mode = gold on white** (`#FFFFFF` cards, `#FAFAF7` background). **Dark mode = gold on black** (`#1A1A1C` cards, `#0E0E0F` background) — both modes are first-class and every screen must be checked in both. Gold is used for: primary CTA buttons, active nav icon + underline, header gradient card on Home, price text, badges, links. Text ON gold is always dark (`AppColors.textOnPrimary`), never white. Never hardcode colors, spacing, radii or text styles — use `core/theme/app_colors.dart` (theme-aware helpers `AppColors.card(context)`, `AppColors.text(context)`, `AppColors.gold(context)`), `app_spacing.dart`, `app_text_styles.dart`. Fonts: Nunito (en), Vazirmatn (ar/ckb).

## Firestore Rules

Start in **dev mode** (`allow read, write: if true`). Production rules are written in `mobile/firestore.rules` behind comments; enable them in Phase 6 before launch.
