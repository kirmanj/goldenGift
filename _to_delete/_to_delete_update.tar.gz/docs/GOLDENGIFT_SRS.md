# Golden Gift — Software Requirements Specification

| | |
|---|---|
| Product | Golden Gift — personalized gifts marketplace (customer app + admin dashboard) |
| Version | 1.0 (initial) |
| Date | 2026-10-20 |
| Owner | Krmanj |
| Reference design | 30 screenshots in `~/Downloads/GoldenGift/IMG_4475 … IMG_4509` (designer's reference, branded "Gifty"). Golden Gift reproduces the layouts and flows with its own brand: **gold & white (light mode) / gold & black (dark mode)**. |
| Sibling project | `~/AndroidStudioProjects/BB` — same stack, same folder structure and conventions. |

---

## 1. Introduction

### 1.1 Purpose
This document specifies everything needed to implement the Golden Gift platform: screens, behaviour, data model, backend, non-functional requirements and the delivery phases. It is written so that each phase can be implemented in order without re-deciding scope.

### 1.2 Product summary
Golden Gift is a mobile marketplace for personalized and occasion gifts (flowers, frames, engraved items, printed products, handmade goods, gift cards, breakfast boxes, …) for Iraq and the Kurdistan Region. Customers browse by category or occasion, customize a product (text, photos, colors, sizes, dates), pay (cash on delivery, wallet, card/e-wallet gateways), and track orders. Partners (vendors) sell through the platform; admins manage the catalogue, orders, promotions, wallets and content from a web dashboard.

### 1.3 Scope of this release
- **Mobile customer app** (Flutter: iOS, Android, Web) — all screens in §5.
- **Admin dashboard** (Flutter Web) — §9.
- **Backend** on Firebase (Auth, Firestore, Storage, Messaging, Analytics, App Check) with a small set of Cloud Functions — §6–§7.
- **Seller (partner) features** are limited in v1 to onboarding + product/order management inside the admin dashboard with a `seller` role; a dedicated seller app is out of scope.

### 1.4 Definitions
| Term | Meaning |
|---|---|
| Customer | End user buying gifts. |
| Guest | Unauthenticated user browsing the catalogue. |
| Partner / Seller / Store | A vendor whose products are listed on Golden Gift. |
| Admin | Golden Gift staff using the dashboard. |
| Option group | A customization input on a product (Frame Color, Text 1, Upload your photos, …). |
| Credits | Promotional wallet balance earned through referrals / gift cards; spendable only inside the app. |
| Preparation days | Days a partner needs before the item can ship. |
| IQD | Iraqi Dinar, the single currency of the platform (0 decimals). |

---

## 2. Overall description

### 2.1 Users and roles
| Role | Where | Capabilities |
|---|---|---|
| Guest | Mobile | Browse Home, categories, products, product details, AI gift search, promo codes list. Any action needing an account (wishlist, cart checkout, profile pages) redirects to Sign In. Cart is kept locally and merged after sign-in. |
| Customer | Mobile | Everything in §5. |
| Seller | Admin dashboard (restricted) | Manage own store profile, products, order statuses for own items, view own sales. |
| Admin | Admin dashboard | Full control (§9). |

### 2.2 Platform & technology (mandatory)
| Area | Choice |
|---|---|
| Mobile | Flutter 3.x, Dart ≥3.0, package `golden_gift`; iOS 13+, Android 7+ (API 24), Web (PWA) |
| Admin | Flutter Web (light + dark, gold accent), package `golden_gift_admin`, hosted on Firebase Hosting (`goldengift-admin`) |
| State | Riverpod (`flutter_riverpod`, `riverpod_annotation`) |
| Navigation | GoRouter — flat routes; bottom nav via `MainShell` + `IndexedStack`; no `refreshListenable` |
| Backend | Firebase project `goldengift`: Auth, Firestore, Storage, Cloud Messaging, Analytics, App Check, Cloud Functions (Node 20, TypeScript), Remote Config (optional) |
| AI | Gemini via Cloud Function `aiGiftSearch` (Firebase AI Logic / Vertex AI) |
| Payments | Cash on delivery (v1 default), Wallet/Credits (v1), FIB / FastPay / ZainCash / card gateway (Phase 4, behind `app_settings.payments` flags) |
| Localization | `en`, `ar` (RTL), `ckb` Kurdish Sorani (RTL). Admin: English only |
| Currency | IQD, 0 decimals, formatted only through `CurrencyFormatter` |
| Fonts | Nunito (Latin), Vazirmatn (Arabic/Kurdish) |
| Monorepo | `GoldenGift/{mobile, adminDashboard, docs}` exactly like BB |

### 2.3 Brand & design system — Gold & White (light) · Gold & Black (dark)
The brand colour is **gold** (the app is *Golden* Gift). Two first-class themes ship from day one: **Light = gold on white** and **Dark = gold on black**. The user chooses Light / Dark / System in Settings (default: System). Every screen, widget and empty-state illustration must be designed and QA'd in both modes.

| Token | Light | Dark | Use |
|---|---|---|---|
| `primary` / `accent` | `#C9A227` | `#E3C04A` (brighter gold for contrast on black) | Primary buttons, active bottom-nav icon + underline, prices, links ("View All", "Sign In"), selected chip border, wishlist heart, badges |
| `primaryDark` | `#9C7A14` | `#9C7A14` | Gradient start (Home header card, Wallet header, Invite & Earn header) |
| `primarySoft` | `#FBF4DC` | `#2E2710` | Selected chip fill, icon circles, info cards, referral-code box |
| `textOnPrimary` | `#1F1A08` | `#1F1A08` | Text/icons placed ON gold (buttons, header card). Never white on gold — fails contrast. |
| `background` | `#FAFAF7` | `#0E0E0F` | Page background |
| `surface` | `#FFFFFF` | `#1A1A1C` | Cards, bottom-nav pill, app-bar circles, inputs |
| `surfaceSecondary` | `#F3F2EC` | `#242427` | Category tiles, text-area inputs |
| `border` | `#E6E3D8` | `#343438` | Card outlines, input borders |
| `textPrimary` / `textSecondary` / `textHint` | `#1E1E2A` / `#6B6F80` / `#9CA0B0` | `#F4F1E8` / `#B0ADA3` / `#7C7A73` | Text |
| `success` / `successSoft` | `#2E9E5B` / `#E8F6EE` | same / `#163A24` | "Shipped same day" banner, promo "10% Off" ribbon |
| `warning` / `warningSoft` | `#E08A1E` / `#FFF4E5` | same / `#3A2A10` | "Requires N days for preparation" banner |
| `error` / `errorSoft` | `#D32F2F` / `#FDECEC` | same / `#3A1515` | Validation errors, destructive actions, discount % badge |
| `goldShimmer` | `#9C7A14 → #E3C04A → #C9A227` | same | Logo, gift-card tiles, "Featured" badge |

Shape language (from the reference screens): pill-shaped buttons (height 56), pill inputs and search bar, pill chips, rounded cards (radius 18), circular back/cart/wishlist buttons with soft shadow, floating pill bottom-nav with active gold underline. Shadows are near-invisible in dark mode; depth there comes from the `surface` vs `background` step and the 1 px `border`.

Where the reference screenshots use red (buttons, header gradient, prices, badges, active nav, selected chips) Golden Gift uses gold; where they use purple (gift-card tiles) Golden Gift uses `goldShimmer`.

### 2.4 Assumptions & constraints
- Phone number is the primary identity (OTP); email is collected but optional for login.
- Default country code `+964`; other codes selectable.
- All prices are stored and displayed in IQD. (Reference screens show `$`; Golden Gift shows `12,000 IQD`.)
- Delivery is limited to a list of served cities (`app_settings/cities`); each product may be restricted to a subset.
- Cloud Functions are deployed for this project (unlike BB). Every client feature that depends on a function must show a friendly error if the call fails and must never leave data half-written (use Firestore transactions / batched writes).

---

## 3. Navigation map

```
Splash ─► (first run) Onboarding ─► Sign Up / Sign In / Continue as guest ─► Main
Main (bottom nav)
 ├─ Home ─► Notifications · AI Gift Search · Banner link · Category ─► Products ─► Product Details ─► Cart
 │          ├─ All Categories (More) · Popular/Featured/For you (View All ─► Products)
 │          ├─ Gift Cards (View All ─► Gift Cards) ─► Gift Card Designer
 │          ├─ "Request Any Gift" banner ─► Special Requests
 │          ├─ "Sell on Golden Gift" banner ─► Become a Partner
 │          └─ "Design Your Gift Card" banner ─► Gift Cards
 ├─ Cart ─► Checkout ─► Order Success ─► Order Details
 └─ Profile ─► Edit Profile · Orders · My Wishlists · Secret Santa · Saved Cards · My Wallet
              · Invite & Earn · Special Requests · Saved Addresses · My Gift Cards · Promo Codes
              · Contact Us · Language · Settings · Logout
```

Routes are enumerated in `mobile/lib/core/router/app_router.dart` (`AppRoutes`). One screen = one route.

---

## 4. Functional requirements — cross-cutting

### 4.1 Authentication (FR-AUTH)
| ID | Requirement |
|---|---|
| AUTH-1 | Sign Up collects **Your Name**, **Email**, **Mobile Number** (country-code picker, default +964, flag shown) and an optional **referral code** (collapsed link "Have a referral code?" that expands an input). Screen: IMG_4475. |
| AUTH-2 | Submitting Sign Up sends an SMS OTP (Firebase Phone Auth). OTP screen: 6-digit boxes, resend after 60 s, auto-read on Android. |
| AUTH-3 | On first successful OTP the app creates `users/{uid}` (§6.1), generates a unique 6-char referral code, records `referredBy` if a valid code was entered, and creates `wallets/{uid}` with 0 balance. |
| AUTH-4 | Sign In = phone + OTP. Google and Apple sign-in buttons are shown under "Or"; an account created socially must still verify a phone number before checkout. |
| AUTH-5 | "Continue as a guest" opens Main. Guest actions that require an account open a bottom sheet "Sign in to continue" with Sign In / Sign Up. |
| AUTH-6 | Session persists until logout. Logout clears local cart cache, keeps device language. |
| AUTH-7 | Account deletion (Settings) — required by App Store: deletes auth user, anonymizes `users/{uid}` (keeps orders for accounting). |
| AUTH-8 | Validation: name 2–50 chars; email RFC-valid if provided; phone 10 digits for +964 (configurable per country code); referral code must exist and not be the user's own. Inline errors in error-red under the field. |

### 4.2 Localization (FR-L10N)
- All user-facing strings come from ARB files; three languages; RTL mirrored layouts for `ar`/`ckb`.
- Catalogue content (categories, products, banners, option labels, gift-card templates, promo descriptions) is **trilingual** in Firestore: `title`, `titleAr`, `titleKu` (and `description*`). Fallback order: current → en.
- Language switch in Profile ▸ Language, applied immediately without restart.

### 4.3 Locations / delivery coverage (FR-LOC)
- `app_settings/cities` lists served cities (default: Erbil, Sulaymaniyah, Duhok, Baghdad, Basra, Mosul, Kirkuk) — trilingual names, delivery fee per city, `isActive`.
- A product may define `availableCities[]`; when non-empty, Product Details shows the overlay **"Available only in: Erbil, Duhok"** (IMG_4494) and Checkout rejects addresses outside that list with a clear message per cart line.

### 4.4 Pricing, discounts and badges (FR-PRICE)
- Product has `price` and optional `compareAtPrice` (old price). When `compareAtPrice > price`, UI shows old price struck-through and an error-red pill badge with the rounded percentage (IMG_4481: `$35.0 ~~$40.0~~ 13%`).
- `isFeatured` shows the gold-shimmer **★ Featured** badge on the image's top-left corner (IMG_4477).
- Product cards show up to 5 colour dots (bottom-right of image) taken from the first `colorSwatch` option group (IMG_4481).

### 4.5 Notifications (FR-NOTIF)
- FCM push + in-app list. Bell icon on Home shows a gold dot when unread > 0 (IMG_4488).
- Events: order status changes, special-request reply, referral credited, gift card received, Secret Santa draw, admin broadcast.
- Document per notification in `notifications` (§6.13); tapping deep-links to the relevant screen.

### 4.6 Sharing & deep links (FR-SHARE)
- Product **Share** button (IMG_4494) shares `https://goldengift.app/p/{productId}` (Firebase Hosting + Dynamic-link-style routing handled in-app via `go_router` on web and app links on mobile).
- Referral share text includes the code and the link `https://goldengift.app/r/{code}`; opening it pre-fills the code on Sign Up.

### 4.7 Analytics (FR-ANALYTICS)
Log: `sign_up`, `login`, `view_item`, `add_to_cart`, `add_to_wishlist`, `begin_checkout`, `purchase`, `ai_search`, `share`, `referral_share`, `special_request_submit`.

### 4.8 Offline / errors
- Firestore offline persistence on. Catalogue screens show cached data with a subtle "offline" chip.
- Every list screen has: loading skeleton, empty state (illustration + title + subtitle + CTA, as in IMG_4480/IMG_4493), error state with Retry.

---

## 5. Functional requirements — screens (mobile)

Each subsection lists: reference screenshot, layout, behaviour, acceptance criteria (AC). Styling follows §2.3 (gold; verify light and dark).

### 5.1 Splash & onboarding
- Splash: white (light) / black (dark) background, gold logo, loads `app_settings/general`, auth state, locale; routes to Main (or Onboarding on first launch).
- Onboarding: 3 slides (Personalize · Deliver · Earn credits) with Skip; shown once (`SharedPreferences`).
- **AC:** cold start to Main ≤ 2.5 s on mid-range Android with warm cache.

### 5.2 Sign Up / Sign In / OTP — IMG_4475
Layout: logo centered top, title "Create Your Account", subtitle "Register now and start creating personalized gifts in minutes!", section label "Sign Up", labelled pill inputs (Your Name, Email, Mobile Number with country-code selector inside the field), link "🎁 Have a referral code?", full-width gold **Sign Up** button, "Already have an account? **Sign In**", "Or", "Continue as a guest", social buttons.
Behaviour: §4.1. Sign In screen mirrors the layout with only the phone field.
**AC:** invalid inputs never reach Firebase; OTP resend disabled 60 s; guest path reaches Home without any network call besides catalogue.

### 5.3 Main shell & bottom navigation — IMG_4476 (bottom)
Floating white pill with three items **Home · Cart · Profile**; active item gold icon + label + 28 px gold underline; cart item shows a gold count badge when > 0. Tabs preserve scroll position (IndexedStack).

### 5.4 Home — IMG_4476, 4477, 4478, 4479, 4488
Vertical scroll with these sections, in this order; every section is data-driven and hidden when empty:
1. **Header card** (gold gradient, rounded 24): greeting by local time ("Good morning/afternoon/evening"), user first name (or "Guest"), bell button (surface circle, gold dot if unread). Inside: white **AI Gift Search** bar — sparkle icon in soft-gold square, title "AI Gift Search", hint "Describe who it's for or the occasion", gold arrow. Tapping opens §5.6.
2. **Banner carousel** (`banners` where `placement = homeTop`), 16:7 images, auto-play 5 s, gold dot indicator. Each banner has an action: `category`, `product`, `url`, `route` (e.g. `/special-requests`, `/become-partner`, `/gift-cards`).
3. **Category grid**: 2 rows × 4 tiles — first 7 `categories` ordered by `sortOrder` + a **More** tile (gold rounded icon) → All Categories (§5.7). Tile: soft-grey rounded square with 3D icon image, label under it.
4. **Popular** (title + gold "View All") → 2-column product cards; source: products ordered by `salesCount desc` limit 6.
5. **Promo banner "Request Any Gift — We'll find it for you"** → Special Requests (§5.17). (Second `banners` placement: `homeMid1`.)
6. **Gift Cards** horizontal list — gold-shimmer gradient tiles (icon, "GIFT CARD", template name, amount) from `gift_card_templates` ordered by `sortOrder`; "View All" → My Gift Cards / shop.
7. **Featured** (products where `isFeatured`), 2-column cards with ★ Featured badge.
8. **Promo banner "Sell on Golden Gift — Become a partner"** → Become a Partner (§5.23). (`homeMid2`)
9. **For you** — personalized: products from the user's most-viewed categories (local history) or, for guests, newest products.
10. **Carousel 2** (`homeBottom`, e.g. "Design Your Gift Card — Make it personal") → Gift Cards.
11. **Profile completion card** (soft-gold, sparkle icon): "Complete your profile to unlock better recommendations" + **Go to profile →** button; shown while `profileCompleted == false` (name, email, birthday, gender, city filled).
12. **Discover**: horizontally scrolling chips (**All** selected gold + category chips with icon) and an infinite 2-column product grid filtered by the selected chip (page size 20).
13. **Referral bottom sheet** (IMG_4488) — shown once per install after the second app open for signed-in users: "Referral rewards" chip, "Invite friends, earn credits", two stat tiles (amount for *Friend joins* / *First paid order*, values from `app_settings/referral`), explanatory rows, buttons **My Rewards** (outline) / **Invite** (gold), "Maybe later".
**AC:** Home renders from cache instantly; each section is its own Riverpod provider and failure of one section never blanks the page; images cached (`cached_network_image`) with shimmer placeholders.

### 5.5 Notifications
List grouped by day, unread rows with soft-gold background, tap → deep link, swipe to delete, "Mark all as read".

### 5.6 AI Gift Search
Screen: large text area "Describe who it's for or the occasion" (e.g. "my sister's graduation, she loves plants, budget 50,000"), optional chips for occasion / budget / recipient, gold **Find gifts** button. Calls Cloud Function `aiGiftSearch({query, locale, budgetMax})` which asks Gemini to map the query to category ids + keywords, then returns up to 12 product ids ranked; the app displays them as product cards with a one-line "why" caption. Each query is logged to `ai_searches`. Rate limit 20 queries / user / day (function enforces). Fallback when the function fails: plain keyword search over `products.searchKeywords`.

### 5.7 All Categories — IMG_4496 … 4500
App bar: circular back, title "All Categories", circular cart button. Pill search "Search for a category" filtering locally. 3-column grid of tiles (soft-grey square with 3D illustration, label beneath, two-line wrap). Tap → Products filtered by that category.
Initial category list (seeded by admin, editable): Golden Gift Home, Packages, Easter Day, Mother's Day, Teacher's Day, Mugs, Skin and Body Care, Tote Bags, Makeup, Jewelry and Watches, Handmade, Flowers, Magnets, Breakfast, Winter Essentials, Phone Cases, New Borns, Button Badge, Caps, Custom Clothing, Puzzles, String Art, Printed T-Shirts, Rocks, Resin, Love, Kids, Birthdays, Anniversary, Keychains, Kurdistan (local souvenirs), Gift Cards, Frames, Leather, Graduation, Engraving, Candles, Perfume, 3D, Chocolate, Crochet, Artificial Flowers, Accessories, Wall Decorations, Father's Day, Valentine, Matching Sets, New Year, Christmas, Home Fragrance.
Categories carry `type: occasion | productType` so Admin can show occasion categories first around holidays (`isSeasonal`, `activeFrom/activeTo`).

### 5.8 Products list — IMG_4481, 4482, 4495
App bar: back, "Products", cart. Pill search "Search for a product" (debounced 400 ms, searches `searchKeywords` array-contains-any of the tokens) + filter button (bottom sheet: price range, sort by newest / price asc / price desc / popular, availability: same-day only, discount only, city). Horizontal category chips (selected chip = soft-gold fill, gold border). 2-column product cards:
- Image (square, rounded 14), **wishlist heart** (surface circle, gold outline heart; filled when saved), ★ Featured badge, colour dots.
- Name (2 lines, ellipsis), price, old price + % badge when discounted.
Infinite scroll, 20 per page, pull-to-refresh. Tap → Product Details.
**AC:** search + category + filter compose into a single Firestore query (indexes in `firestore.indexes.json`); no client-side filtering beyond the page.

### 5.9 Product Details — IMG_4494, 4501 … 4509
Layout top→bottom:
1. App bar: back, "Product Details", cart (badge).
2. **Image carousel** (rounded card, soft-grey background, dots) with wishlist heart; optional overlay chip "Available only in: …" (§4.3); discount % badge below carousel (IMG_4508).
3. **Availability banner**: warning-soft "⚠ This product requires N days for preparation" or success-soft "🚚 This product can be shipped same day".
4. Title (2–3 lines), **price** (large gold) with struck old price, **Share** pill button.
5. **About the Product** — collapsed to 2 lines with chevron, expands inline (rich text with line breaks).
6. **Option groups** rendered in `sortOrder` (one widget per `OptionType`, see table). Required groups are validated on Add to Cart; the button stays enabled and scrolls to the first missing group with an error-red hint.
7. Sticky bottom bar: quantity stepper + gold **Add to Cart** (shows computed line price = (price + Σ option priceDelta) × qty).

| OptionType | Reference | UI | Data captured |
|---|---|---|---|
| `imageVariant` | Frame Color (IMG_4502), Size (IMG_4505), Color Brown/Black (IMG_4504) | Horizontal tiles 150×150 with image + label; selected = gold border 2 px | `{groupId, valueId, label}` |
| `textVariant` | Size "30x30cm" (IMG_4509) | Pill chips | `{groupId, valueId, label}` |
| `colorSwatch` | Text Color, Color (IMG_4507/4509) | Row of 44 px circles in a grey pill; selected = dark ring | `{groupId, valueId, hex, label}` |
| `text` | Text 1 (0/50), Text 2/Name (0/100), Name (0/12) | Grey rounded text area, live counter `n/max` | `{groupId, text}` |
| `longText` | Notes (0/500) | Multi-line, counter | `{groupId, text}` |
| `date` | Date (Optional) (IMG_4507) | Grey pill "Select a date" → date picker | `{groupId, date}` |
| `photoUpload` | Upload your photos 1–4 (IMG_4502) | Grid of dashed gold boxes numbered 1..N; tap → camera/gallery → crop → thumbnail with ✕; uploads to Storage `uploads/{uid}/{cartItemId}/{n}.jpg` on Add to Cart with progress | `{groupId, urls[]}` |
| `quantity` | — | Stepper in bottom bar | `qty` |

Each option value may carry `priceDelta` (e.g. Large +5,000 IQD) and `stock`. The product's `preparationDays` may be overridden per value (`preparationDaysOverride`).
**Add to Cart:** writes `carts/{uid}/items/{itemId}` (guest: local Hive/SharedPreferences, merged on login) with a snapshot of product name, image, unit price, selections, computed line total; shows a snackbar "Added to cart — View cart". Re-adding the same product with identical selections increments qty.
**AC:** validation messages are localized; photo uploads are compressed to ≤ 1600 px / 85 % before upload; option groups render in < 16 ms frames (no jank on 3-year-old devices).

### 5.10 Cart — IMG_4480
Empty state: mascot illustration, "Your Golden Gift cart is feeling lonely!", subtitle, gold **Start Shopping** → Home.
Filled state: list of cart items (image, name, selection summary e.g. "Frame: Walnut · Text: Happy B-day · 2 photos", unit price, qty stepper, remove), grouped by store when the cart contains multiple partners; summary card: subtotal, estimated delivery, promo code field (apply/remove), credits toggle, total; gold **Checkout** button. A line whose product became unavailable shows an error-red note and is excluded from totals.

### 5.11 Checkout
Steps on one scrolling page: (1) delivery address (select from Saved Addresses or add new; city must be served and allowed by every item), (2) delivery date & slot — earliest date = today + max(preparationDays) (+1 if after cut-off `app_settings/general.sameDayCutoff`), (3) gift options: "This is a gift" → hide prices on invoice, gift message (≤ 200 chars), (4) payment method (Cash on delivery · Wallet/Credits · Card/e-wallet when enabled), (5) summary + **Place Order**.
Order placement is a Firestore transaction / callable `placeOrder`: validates stock & prices server-side, applies promo & credits, decrements stock, creates `orders/{id}` with `status = pending`, clears cart, writes wallet transaction if credits used, increments `salesCount`. Order Success screen shows order number, ETA, **Track order** / **Continue shopping**.

### 5.12 Orders & Order Details
Orders list: tabs Active / Completed / Cancelled; card with order number, date, total, status chip (colour per status), first item thumbnails. Details: timeline (`status_history`), items with personalization details and uploaded photos, address, payment, totals; actions: Cancel (allowed while `pending`/`confirmed`), Reorder, Contact support, Rate (after delivered → `reviews`).

### 5.13 Profile — IMG_4490
Header: avatar circle (initial on gold if no photo), name, phone, **Edit** outline pill. Section "Account" rows with coloured round icons, title, optional gold subtitle, chevron:
Orders · My Wishlists ("Gifts you've saved") · Secret Santa ("Family, friends and work exchanges") · Saved Cards · My Wallet · Invite & Earn ("Earn 5,000 IQD per friend" — value from settings) · Special Requests · Saved Addresses · My Gift Cards · Promo Codes · Contact Us · Language · Settings (notifications toggle, theme Light/Dark/System, delete account) · Logout. Guests see Sign In card instead of the header.

### 5.14 Edit Profile
Fields: photo, name, email, phone (read-only, change via OTP flow), birthday, gender (optional), city. Saves to `users/{uid}`; sets `profileCompleted`.

### 5.15 My Wishlists
Grid of saved products (same card as §5.8) with remove; v1 is a single default wishlist; data model supports named lists (`wishlists/{uid}/items` with `listId`, default `"default"`), UI for multiple lists is Phase 4.

### 5.16 Secret Santa
Create group: name, type (family/friends/work), budget, exchange date, members (contacts or phone numbers). Members join via link; organiser taps **Draw** → Cloud Function `drawSecretSanta` assigns giver→receiver with no self-match and (optional) exclusions, notifies members; each member sees only their assignee and a "Shop for them" button that opens Products with the budget filter.

### 5.17 Special Requests — IMG_4492
Illustration, title "Special Requests", subtitle "Got a special idea? Tell us about it and we'll reach out soon to bring it to life!", image picker tile (dashed, up to 5 images), text area "Write your idea here" (≤ 1000 chars), gold **Submit your request**. After submit → list of my requests with status chips (Submitted · In review · Quoted · Accepted · Rejected · Completed) and a message thread with admin (`special_requests/{id}/messages`). When admin sends a quote, the customer can **Accept** which creates a draft order for the quoted amount.

### 5.18 My Wallet — IMG_4493
Gold gradient header "My Wallet"; white card "Available Balance" with large amount; below, transaction list (type icon, title, date, ± amount) or empty state "No Transactions Yet / Your Transaction History will appear here". Top-up button appears only when an online payment gateway is enabled. Wallet balance = `wallets/{uid}.balance` (real money, refunds/top-ups) + `credits` (promotional). Checkout can use both; credits are consumed first.

### 5.19 Invite & Earn — IMG_4489
Gold gradient header with subtle gift-icon pattern: "Invite & Earn", "Golden Gift Credits Balance", large amount. Stat cards: **Successful Referrals** ("Friends who signed up and placed a paid order") and **Pending Referrals** ("Friends who signed up — reward when they order") with gold counts. "Invite Friends" copy, soft-gold box with **Your referral code** (large spaced gold letters) + copy button + "Share it with friends — you'll both get {amount}". Gold **Invite Friends** (system share sheet). Link "Learn more about referrals" → bottom sheet with rules.
Rules (values in `app_settings/referral`): friend gets `joinBonus` credits on sign-up with code; referrer gets `orderBonus` credits when the friend's first order is **delivered and paid**; max `maxReferralsPerMonth`; self-referral and same-device abuse rejected by function `onOrderDelivered`.

### 5.20 Saved Addresses
List cards (label, name, phone, city, area, street, building, notes; "Default" chip); add/edit form with city dropdown (served cities only), optional map pin (Google Maps) — map is Phase 4; delete with confirmation.

### 5.21 Saved Cards
Only when a card gateway is enabled: list of tokenized cards (brand, last4, expiry); add card opens the gateway's hosted page; delete. Never store PAN.

### 5.22 My Gift Cards & Gift Card Designer
- Shop: templates from Home section; each template has name, artwork, preset amounts (e.g. 15,000 / 25,000 / 100,000 IQD) or custom amount within min/max.
- **Designer** ("Design Your Gift Card — Make it personal"): choose template colour, upload a photo, write a message, recipient name + phone/email, send now or schedule date. Pay via checkout (`orderType = giftCard`).
- Received cards appear under **My Gift Cards** with code, balance, expiry; **Redeem** adds the balance to wallet credits (function `redeemGiftCard`).

### 5.23 Promo Codes — IMG_4491
Header card "Love a Good Deal? We Do Too! 🎉" with illustration; list of coupon tickets: green vertical ribbon "10% Off" (or amount), code (bold) + copy icon, dashed divider, description, "Expires on: dd/mm/yyyy" in green. Only `isPublic && active && not expired` codes are listed; private codes work at checkout but are not listed. Rules: percentage or fixed, min order, max discount, usage limit total / per user, first-order-only, category/store restriction.

### 5.24 Contact Us & Support
Cards: WhatsApp, phone, email, Instagram (values from `app_settings/general`), plus an in-app message form that creates a `special_requests` doc with `type = support`.

### 5.25 Become a Partner (Sell on Golden Gift)
Landing with benefits + form: store name, owner name, phone, city, category, Instagram, sample product photos. Creates `stores/{id}` with `status = pendingApproval`; admin approves in dashboard and grants `seller` role; partner then uses the admin dashboard (restricted) to manage products and orders.

### 5.26 Reviews
After delivery: 1–5 stars + text + photos per product; aggregated `ratingAvg`/`ratingCount` on product and store (function `onReviewWrite`). Shown on Product Details below About (Phase 4).

---

## 6. Data model (Firestore)

All documents carry `createdAt`, `updatedAt` (server timestamps). Trilingual fields use suffixes `Ar`, `Ku`. Enum string values are listed in §6.15 and must match `app_constants.dart` / `admin_constants.dart`.

### 6.1 `users/{uid}`
`name`, `email?`, `phone`, `countryCode`, `photoUrl?`, `birthday?`, `gender?`, `city?`, `locale`, `role` (customer/seller/admin), `storeIds[]`, `referralCode`, `referredBy?` (uid), `profileCompleted`, `fcmTokens[]`, `notificationsEnabled`, `totalOrders`, `totalSpent`, `lastSeenAt`, `isBlocked`.
Subcollections: `addresses/{id}` (`label, name, phone, city, area, street, building, floor, notes, lat?, lng?, isDefault`), `saved_cards/{id}` (`gateway, token, brand, last4, expMonth, expYear`).

### 6.2 `stores/{storeId}`
`name*`, `description*`, `logoUrl`, `coverUrl`, `ownerUid`, `phone`, `city`, `status` (pendingApproval/active/suspended), `ratingAvg`, `ratingCount`, `productCount`, `ordersCount`, `commissionPercent`, `payoutInfo{}`.

### 6.3 `categories/{id}`
`title*`, `iconUrl`, `type` (occasion/productType), `sortOrder`, `isActive`, `isSeasonal`, `activeFrom?`, `activeTo?`, `parentId?`, `productCount`. Subcollection `subcategories` reserved.

### 6.4 `products/{id}`
`title*`, `description*`, `storeId`, `categoryIds[]`, `images[]`, `price`, `compareAtPrice?`, `currency: "IQD"`, `isActive`, `isFeatured`, `availability` (sameDay/preparationDays/outOfStock), `preparationDays`, `availableCities[]`, `stock?` (null = unlimited), `salesCount`, `viewCount`, `ratingAvg`, `ratingCount`, `searchKeywords[]` (lower-cased tokens of titles in 3 languages + tags), `tags[]`, `optionGroups[]`:
```
optionGroups: [{
  id, type (OptionType), label*, required, sortOrder, maxLength?, minPhotos?, maxPhotos?,
  values?: [{ id, label*, imageUrl?, hex?, priceDelta, stock?, preparationDaysOverride? }]
}]
```
Subcollection `reviews/{id}`: `userId, userName, rating, text, images[], orderId, isApproved`.

### 6.5 `carts/{uid}/items/{itemId}`
`productId, storeId, titleSnapshot, imageSnapshot, unitPrice, qty, selections[] ({groupId, type, label, valueId?, valueLabel?, text?, date?, urls[]?, priceDelta}), lineTotal, preparationDays, addedAt`.

### 6.6 `wishlists/{uid}/items/{productId}`
`listId ("default"), productId, addedAt` (+ denormalized `title, image, price`).

### 6.7 `orders/{orderId}`
`orderNumber` (GG-YYMM-#####), `userId`, `storeIds[]`, `items[]` (cart item snapshot + `storeId`, `status` per item for multi-vendor), `subtotal`, `discount`, `promoCode?`, `creditsUsed`, `walletUsed`, `deliveryFee`, `total`, `paymentMethod`, `paymentStatus`, `paymentRef?`, `address{}` (snapshot), `deliveryDate`, `deliverySlot?`, `isGift`, `giftMessage?`, `hidePrices`, `status`, `cancelReason?`, `orderType` (standard/giftCard/specialRequest), `referralCredited`, `rewards{}`.
Subcollection `status_history/{id}`: `status, byUid, byRole, note, at`.

### 6.8 `banners/{id}`
`imageUrl*`, `placement` (homeTop/homeMid1/homeMid2/homeBottom), `action{type: category|product|url|route, value}`, `sortOrder`, `isActive`, `startAt?`, `endAt?`.

### 6.9 `promo_codes/{code}`
`code` (doc id, upper-case), `title*`, `description*`, `type` (percent/fixed), `value`, `maxDiscount?`, `minOrder?`, `usageLimit?`, `usageCount`, `perUserLimit`, `firstOrderOnly`, `categoryIds[]?`, `storeIds[]?`, `isPublic`, `isActive`, `expiresAt`.
`promo_codes/{code}/usages/{uid}` → `count`.

### 6.10 `gift_card_templates/{id}` and `gift_cards/{id}`
Template: `name*`, `artworkUrl`, `gradientStart/End`, `presetAmounts[]`, `minAmount`, `maxAmount`, `sortOrder`, `isActive`.
Card: `code` (12 chars, unique), `templateId`, `amount`, `balance`, `purchaserUid`, `recipientName`, `recipientPhone?`, `recipientEmail?`, `recipientUid?`, `message`, `photoUrl?`, `scheduledAt?`, `sentAt?`, `redeemedAt?`, `expiresAt`, `status` (pending/sent/redeemed/expired), `orderId`.

### 6.11 `wallets/{uid}`
`balance` (real), `credits` (promo), `currency`. Subcollection `transactions/{id}`: `type` (WalletTxnType), `amount` (+/-), `bucket` (balance/credits), `title*`, `orderId?`, `referralId?`, `giftCardId?`, `byUid?`, `balanceAfter`, `creditsAfter`.
Only Cloud Functions / admin write wallets.

### 6.12 `referrals/{id}`
`referrerUid`, `referredUid`, `code`, `status` (pending/completed/cancelled), `joinBonusPaid`, `orderBonusPaid`, `firstOrderId?`, `completedAt?`.

### 6.13 `notifications/{id}`
`userId` (or `"all"` for broadcast), `title*`, `body*`, `type`, `data{route, id}`, `imageUrl?`, `isRead`, `createdAt`.

### 6.14 `special_requests/{id}`, `secret_santa_groups/{id}`, `ai_searches/{id}`, `app_settings/{doc}`
- Special request: `userId, type (gift/support), text, images[], status, quoteAmount?, quoteNote?, orderId?, assignedAdminUid?`; `messages/{id}`: `senderUid, role, text, images[], at`.
- Secret Santa: `name, type, budget, exchangeDate, organiserUid, status (open/drawn/closed), inviteCode`; `members/{uid}`: `name, phone, joinedAt, assigneeUid?, wishlistNote?`.
- AI search: `userId?, query, locale, resultProductIds[], latencyMs, at`.
- `app_settings/general`: `supportPhone, whatsapp, email, instagram, sameDayCutoff ("14:00"), minOrder, maintenanceMode, minAppVersion{ios,android}`.
- `app_settings/cities`: `items[{id, name*, deliveryFee, isActive}]`.
- `app_settings/referral`: `joinBonus, orderBonus, maxReferralsPerMonth, creditsExpiryDays`.
- `app_settings/payments`: `cashOnDelivery, wallet, card, fastPay, zainCash` (bool each) + gateway config ids.
- `admins/{uid}`: `name, email, role (super/ops/content/finance), permissions[]`; `admin_audit_log/{id}`: `adminUid, action, target, before, after, at`.

### 6.15 Enum values (stored strings)
- `OrderStatus`: pending · confirmed · preparing · readyForDelivery · outForDelivery · delivered · cancelledByBuyer · cancelledBySeller · returned · refunded
- `PaymentMethod`: cashOnDelivery · wallet · card · fastPay · zainCash
- `PaymentStatus`: pending · paid · failed · refunded
- `OptionType`: imageVariant · textVariant · colorSwatch · text · longText · date · photoUpload · quantity
- `ProductAvailability`: sameDay · preparationDays · outOfStock
- `ReferralStatus`: pending · completed · cancelled
- `SpecialRequestStatus`: submitted · inReview · quoted · accepted · rejected · completed
- `WalletTxnType`: topUp · orderPayment · refund · referralCredit · giftCardRedeem · adminAdjustment

### 6.16 Storage layout
`products/{productId}/{n}.jpg` · `categories/{id}.png` · `banners/{id}.jpg` · `uploads/{uid}/{cartItemId}/{n}.jpg` (customer photos; copied to `orders/{orderId}/…` on order placement by function) · `special_requests/{id}/{n}.jpg` · `users/{uid}/avatar.jpg` · `gift_cards/{id}/photo.jpg`.

### 6.17 Security rules (Phase 6, summarised)
Public read: products, categories, banners, gift_card_templates, app_settings. Owner-only: users/*, carts, wishlists, notifications (read), wallets (read). Orders: create by owner with server-validated totals (function path preferred), read by owner/seller of included store/admin, update by admin/seller (status only). Wallets, referrals, gift_cards, promo usage: function/admin write only. Admin = custom claim `admin == true`; seller = claim `seller == storeId`.

---

## 7. Backend logic (Cloud Functions, TypeScript)

| Function | Trigger | Responsibility |
|---|---|---|
| `onUserCreate` | Auth onCreate | Create `users` + `wallets` docs, assign referral code, apply `referredBy` join bonus (credits) and create `referrals` doc. |
| `placeOrder` | callable | Validate cart server-side (prices, stock, cities, promo, credits), create order in a transaction, decrement stock, clear cart, copy uploaded photos, send notification to customer + store + admins. |
| `onOrderStatusChange` | Firestore update | Write `status_history`, push notification, on `delivered && paid`: increment user totals, credit referrer (`orderBonus`) once (`referralCredited` flag), on refund reverse wallet. |
| `aiGiftSearch` | callable | Gemini prompt → structured {categories, keywords, budget} → Firestore query → ranked product ids; log; rate-limit. |
| `redeemGiftCard` | callable | Atomically move balance to wallet credits; mark card redeemed. |
| `issueGiftCard` | on order paid (`orderType = giftCard`) | Generate code, create `gift_cards` doc, notify recipient (SMS/push/email). |
| `drawSecretSanta` | callable | Derangement over members; write assignees; notify. |
| `onReviewWrite` | Firestore | Recompute product/store rating aggregates. |
| `sendBroadcast` | callable (admin) | Push to topic `all` / segment. |
| `expireCredits` | scheduled daily | Expire credits older than `creditsExpiryDays`; expire gift cards; close seasonal categories. |
| `setAdminClaim` | callable (super admin) | Grant/revoke `admin` / `seller` custom claims. |

All functions: region `europe-west1`, App Check enforced, structured logs, idempotent (keyed by order id / referral id).

---

## 8. Non-functional requirements
| Area | Requirement |
|---|---|
| Performance | Home first paint ≤ 1.5 s warm; list scroll 60 fps; images lazy + cached; Firestore reads per Home open ≤ 60 docs. |
| Reliability | All multi-document writes in transactions/batches; retries with backoff; no partial orders. |
| Security | App Check on all services; rules per §6.17; no secrets in client; card data only via gateway tokens; photo uploads validated (type, size ≤ 10 MB). |
| Privacy | Account deletion flow; data minimization; privacy policy & terms links in Settings. |
| Accessibility | Minimum touch target 44 px; text scales to 130 %; RTL verified on every screen; colour contrast ≥ 4.5:1 — text on gold is dark `#1F1A08` (≈ 8:1 on `#C9A227`); gold text on black uses `#E3C04A` (≈ 10:1); gold text on white (`#C9A227`) is reserved for ≥ 18 px bold (prices, section links). |
| Localization | 100 % string coverage in 3 languages before release; Kurdish reviewed by a native speaker. |
| Compatibility | iOS 13+, Android 7+; tablets render the same layouts with a max content width of 600 px. |
| Observability | Crashlytics, Analytics events (§4.7), function logs with order id correlation. |
| Maintainability | Feature-first structure, design-system tokens only, `flutter analyze` clean, widget tests for cart math, option validation, promo math; integration test for sign-up → order. |
| Versioning | `minAppVersion` in `app_settings/general` forces update dialog. |

---

## 9. Admin dashboard (Flutter Web)
Login (email/password, admin claim required). Left nav + top bar. Every mutation logs to `admin_audit_log`.
| Module | Capabilities |
|---|---|
| Dashboard | KPIs (orders today, revenue, pending orders, new users, AI searches), orders-per-day chart, top products, low-stock list. |
| Orders | Table with filters (status, store, date, city, payment), detail drawer (items with personalization + uploaded photos download, timeline), status transitions with notes, refund to wallet, print invoice (hides prices when `hidePrices`). |
| Products | CRUD, trilingual fields, image upload/reorder, categories multi-select, pricing & compare price, availability & preparation days, allowed cities, **option-group builder** (all `OptionType`s with values, images, swatches, price deltas, stock), featured toggle, search-keyword regeneration, bulk import CSV. |
| Categories | CRUD, icon upload, ordering (drag), seasonal windows, occasion vs product type. |
| Stores / Partners | Approve applications, edit profile, commission %, suspend, view sales, grant seller claim. |
| Users | Search, view profile/orders/wallet, block, adjust wallet or credits (with reason), impersonate-read. |
| Banners | CRUD per placement with scheduling and action targets. |
| Promo codes | CRUD with all rules in §6.9, usage report. |
| Gift cards | Templates CRUD; issued cards list; manual issue; disable. |
| Special requests | Inbox with statuses, message thread, send quote, convert to order. |
| Referrals | List, fraud flags, settings (bonuses, limits). |
| Secret Santa | Read-only monitoring. |
| Notifications | Broadcast composer (trilingual), history. |
| Settings | `app_settings/*` editors: cities & fees, payments flags, contact info, cut-off time, min version, maintenance mode. |
| Seller view | Same shell with modules limited to own store: Products, Orders (own items), Dashboard (own KPIs), Store profile. |

---

## 10. Delivery phases (implement strictly in order)

| Phase | Scope | Exit criteria |
|---|---|---|
| **0 — Foundation** | Monorepo scaffold (done), `flutter create` platform folders, Firebase project + `flutterfire configure`, design system (`app_colors` light + dark tokens, `app_spacing`, `app_text_styles`, `app_theme` light & dark, `themeModeProvider`), reusable widgets listed in `mobile/CLAUDE.md`, router with all routes, l10n pipeline, `FirestorePaths`, models for users/categories/products/cart, dev seeder with the §5.7 categories + 20 demo products. | App runs on iOS/Android/Web showing Main shell with placeholders; `flutter analyze` clean; seed script populates Firestore. |
| **1 — Browse & customize** | Splash/onboarding, Sign Up/Sign In/OTP/guest, Home (all sections except referral sheet, gift cards, profile-completion), All Categories, Products list + search + filter, Product Details with the full option-group engine, Wishlist, Cart (local + Firestore), Notifications list. | A user can sign up, browse, customize a product with photos and text, and see it in the cart with correct totals. |
| **2 — Order** | Saved Addresses, Checkout, `placeOrder` function, Order Success, Orders & Order Details, cancel/reorder, promo codes (list + apply), cash-on-delivery + wallet payment, order push notifications, Contact Us, Edit Profile, Language, Settings, account deletion. | End-to-end order placed and tracked; admin can change status from Firestore console and the customer is notified. |
| **3 — Growth** | Wallet screen & transactions, Invite & Earn + referral sheet + `onUserCreate`/`onOrderStatusChange` credit logic, Gift cards (templates, designer, purchase, issue, redeem, My Gift Cards), Special Requests with messaging and quotes, profile-completion card, "For you" personalization. | Referral credits are paid exactly once; gift card bought → received → redeemed; special request quoted → order. |
| **4 — Delight** | AI Gift Search (`aiGiftSearch`), Secret Santa, Reviews & ratings, Become a Partner, online payment gateway(s) behind flags, Saved Cards, map pin in addresses, multiple named wishlists. | AI returns relevant products for Arabic/Kurdish/English queries; gateway sandbox payment succeeds. |
| **5 — Admin dashboard** | All modules in §9 (seller-restricted view included), CSV import, invoice print, broadcast. | Ops team runs a day of orders without touching the Firestore console. |
| **6 — Hardening & launch** | Production security rules & indexes, App Check, Crashlytics, performance pass, RTL/translation QA, light + dark mode QA of every screen, store listings, privacy policy, release pipeline (`.github/workflows` like BB), TestFlight / Play internal testing. | Rules deployed; zero P1 bugs in a 1-week beta; app store submissions accepted. |

Each phase ends with: `flutter analyze` clean, widget tests for the phase's logic, SRS updated if anything changed.

---

## 11. Screenshot → requirement map
| File | Screen | SRS |
|---|---|---|
| IMG_4475 | Sign Up | §5.2 |
| IMG_4476–4479 | Home (header, carousel, categories, Popular, Request Any Gift, Gift Cards, Featured, Sell on Gifty, For you, Design Your Gift Card, profile completion, Discover) | §5.4 |
| IMG_4480 | Cart empty state | §5.10 |
| IMG_4481, 4482, 4495 | Products list (Flowers / Handmade / New Borns chips, cards with colour dots, discounts) | §5.8 |
| IMG_4488 | Referral rewards bottom sheet | §5.4 (13) |
| IMG_4489 | Invite & Earn | §5.19 |
| IMG_4490 | Profile | §5.13 |
| IMG_4491 | Promo Codes | §5.23 |
| IMG_4492 | Special Requests | §5.17 |
| IMG_4493 | My Wallet | §5.18 |
| IMG_4494 | Product Details — city restriction, 2-day preparation, breakfast box | §5.9 |
| IMG_4496–4500 | All Categories (50 categories) | §5.7 |
| IMG_4501, 4502 | Product Details — Frame Color image variants, 4 photo uploads | §5.9 |
| IMG_4503, 4504 | Product Details — Text 1 (50), Text 2/Name (100), Color image variants | §5.9 |
| IMG_4505 | Product Details — same-day shipping, Size variants | §5.9 |
| IMG_4506, 4507 | Product Details — Name (12), Date (optional), colour swatches, 12-day preparation | §5.9 |
| IMG_4508, 4509 | Product Details — discount badge, Text Color swatches, Text (200), Size chip, Notes (500) | §5.9 |

---

## 12. Open items for the owner to confirm
1. Final brand assets (logo, mascot illustration for empty states, 3D category icons).
2. Served cities and per-city delivery fees for launch.
3. Referral amounts in IQD (reference uses $5/$5) and credit expiry.
4. Which online payment gateway to integrate first (FIB / FastPay / ZainCash / card).
5. Commission model for partners and payout schedule.
6. Whether gift-card and Secret Santa features ship in v1 or are deferred (they are Phases 3–4 here).
