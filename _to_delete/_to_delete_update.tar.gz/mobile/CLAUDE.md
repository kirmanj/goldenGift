# Golden Gift Mobile App

Package name: `golden_gift` (imports use `package:golden_gift/...`).
Flutter 3.x, Dart SDK >=3.0.0 <4.0.0. Scope: `../docs/GOLDENGIFT_SRS.md`.

## Tech Stack

- **State management:** Riverpod (`flutter_riverpod`) — NOT Bloc, NOT Provider
- **Navigation:** GoRouter — flat route list in `lib/core/router/app_router.dart`, no ShellRoute, no `refreshListenable`
- **Bottom nav:** `core/widgets/main_shell.dart` (IndexedStack: Home · Cart · Profile)
- **Backend:** Firebase Auth, Firestore, Storage, Messaging, Analytics, Functions, App Check
- **Localization:** ARB files in `assets/lang/` → `flutter gen-l10n` → `lib/l10n/` (never edit generated files)

## Architecture (feature-first)

```
lib/
  core/        constants, providers, router, services, theme, utils, widgets
  features/    {feature}/data/datasources · presentation/{providers,screens,widgets}
  models/      shared data models (ProductModel, OrderModel, …) — fromMap/toMap, trilingual fields
  l10n/        generated
```

Feature folders (one per SRS §5 section): auth, home, categories, products, product_details, search, ai_search, cart, checkout, orders, wishlist, profile, addresses, wallet, referrals, gift_cards, special_requests, secret_santa, promo_codes, notifications, support, seller.

## Design System — Gold & White / Gold & Black (mandatory)

| What | File |
|------|------|
| Colors | `core/theme/app_colors.dart` — `AppColors.primary` (#C9A227 gold), `accent`, `primarySoft`, `headerGradient`, theme-aware helpers `AppColors.card/text/textMuted/field/line/soft/gold(context)` |
| Spacing / radii / shadows | `core/theme/app_spacing.dart` — `AppSpacing.md`, `AppRadius.pill`, `AppElevation.card` |
| Typography | `core/theme/app_text_styles.dart` |
| Theme | `core/theme/app_theme.dart` |

- Buttons, inputs, chips and the search bar are **pill-shaped** (`AppRadius.pill`). Cards use `AppRadius.lg`.
- Gold = CTA buttons, active nav, Home header gradient, prices, discount/featured badges, links, selected chip border. Never gold page backgrounds.
- Light mode: gold on white. Dark mode: gold on black (`ThemeMode` from `themeModeProvider`, default system). Every new screen is reviewed in BOTH modes; use the `AppColors.*(context)` helpers instead of light-only constants.
- Text on gold surfaces is dark (`AppColors.textOnPrimary`), never white (contrast).
- `Color.withValues(alpha: x)`, not `withOpacity`.
- Screen padding `AppSpacing.screenPadding`. Product grid = 2 columns, gap `AppSpacing.gridGap`.
- Currency: `CurrencyFormatter.format()` (IQD, 0 decimals).
- Fonts: Nunito (en), Vazirmatn (ar/ckb) via `AppTextStyles.fontFamily(locale)`.

## Reusable widgets to build first (Phase 0) and always reuse
`GGAppBar` (back circle + centered title + optional cart icon), `PrimaryButton`, `OutlineButton`, `GGInput`, `GGSearchBar`, `CategoryChip`, `CategoryTile`, `ProductCard`, `SectionHeader` (title + "View All"), `BannerCarousel`, `InfoBanner` (warning/success), `EmptyState`, `ErrorState`, `SkeletonLoader`, `WishlistHeart`, `PriceText`, `DiscountBadge`, `FeaturedBadge`.
