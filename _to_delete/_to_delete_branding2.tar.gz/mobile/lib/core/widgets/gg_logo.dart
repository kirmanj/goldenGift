import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Golden Gift logo. Picks the right asset for the current theme.
/// - [GGLogoVariant.emblem]: square gift-box mark (transparent, works on both themes)
/// - [GGLogoVariant.wide]: horizontal emblem + wordmark (dark/light file per theme)
class GGLogo extends StatelessWidget {
  const GGLogo({super.key, this.variant = GGLogoVariant.emblem, this.height = 40});

  final GGLogoVariant variant;
  final double height;

  @override
  Widget build(BuildContext context) {
    final dark = AppColors.isDark(context);
    final asset = switch (variant) {
      GGLogoVariant.emblem => 'assets/images/logo_transparent.png',
      GGLogoVariant.wide =>
        dark ? 'assets/images/logo_wide_dark.png' : 'assets/images/logo_wide_light.png',
    };
    return Image.asset(asset, height: height, fit: BoxFit.contain, semanticLabel: 'Golden Gift');
  }
}

enum GGLogoVariant { emblem, wide }
